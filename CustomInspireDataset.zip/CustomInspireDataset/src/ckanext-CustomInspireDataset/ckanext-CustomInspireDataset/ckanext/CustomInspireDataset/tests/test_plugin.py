"""Tests for plugin.py."""
import ckanext.CustomInspireDataset.plugin as plugin

def test_plugin():
    pass